SET SERVEROUTPUT ON
SET VERIFY OFF
SET LINES 2000
SET TRIMSPOOL OFF
SPOOL /home/oracle/scripts/dba_scripts/EFV_ORDER_UPD_SDO_40269.log

--67g_EFV_ORDER_UPD_Mahesh_Panchal

UPDATE EFARMS.EFV_ORDER k
  SET
    FF_TEAM_ID = 4799935,
    FF_TEAM_NAME = 'CT FMAR Rep',
    FF_TEAM_MEMBER_ID = 8508451,
    FF_TEAM_MEMBER_NAME = 'Mahesh Panchal',
    LAST_MODIFIED_BY = 'SYSTEM',
    LAST_MODIFIED_DATE = SYSDATE
  WHERE
   k.CURRENT_STATUS_CD = 545
   AND k.FF_TEAM_MEMBER_ID is null
   AND k.FF_TEAM_ID = 4799935
   AND k.JURIS_ID in (4,5,6,8,9,10,11,12,13,15,16,17,18,19,21,24,25,26,29,31,33,34,36,37,39,43,44,46,47,49,52);

COMMIT;


--68g_EFV_ORDER_UPD_Ashish_Rajput

UPDATE EFARMS.EFV_ORDER k
  SET
    FF_TEAM_ID = 4799935,
    FF_TEAM_NAME = 'CT FMAR Rep',
    FF_TEAM_MEMBER_ID = 12601776,
    FF_TEAM_MEMBER_NAME = 'Ashish Rajput',
    LAST_MODIFIED_BY = 'SYSTEM',
    LAST_MODIFIED_DATE = SYSDATE
  WHERE
   k.CURRENT_STATUS_CD = 545
   AND k.FF_TEAM_MEMBER_ID is null
   AND k.FF_TEAM_ID = 4799935
   AND k.JURIS_ID in (1,2,3,7,14,20,22,23,27,28,30,32,35,38,41,48,50,51);

COMMIT;


--70g_EFV_ORDER_UPD_Gajraj_Gholane

UPDATE EFARMS.EFV_ORDER k
  SET
    FF_TEAM_ID = 4799935,
    FF_TEAM_NAME = 'CT FMAR Rep',
    FF_TEAM_MEMBER_ID = 11985419,
    FF_TEAM_MEMBER_NAME = 'Gajraj Gholane',
    LAST_MODIFIED_BY = 'SYSTEM',
    LAST_MODIFIED_DATE = SYSDATE
  WHERE
(upper(k.CUSTOMER_NAME) like upper('%Wynn Resorts, Limited%')
        OR upper(k.CUSTOMER_NAME) like upper('%Guild Mortgage Company, LLC%')
        OR upper(k.CUSTOMER_NAME) like upper('%Pediatrix%')
        OR upper(k.CUSTOMER_NAME) like upper('%Crown Castle Inc.%')
        OR upper(k.CUSTOMER_NAME) like upper('%Rialto Capital Management, LLC%')
        OR upper(k.CUSTOMER_NAME) like upper('%Bank of America%')
        OR upper(k.CUSTOMER_NAME) like upper('%Bank of America (Dallas)%')
        OR upper(k.CUSTOMER_NAME) like upper('%The Bank Of New York Mellon Corporation%')
        OR upper(k.CUSTOMER_NAME) like upper('%Republic Services, Inc.%')
        OR upper(k.CUSTOMER_NAME) like upper('%Esperion Therapeutics, Inc%')
        OR upper(k.CUSTOMER_NAME) like upper('%DYCOM INDUSTRIES, INC.%')
        OR upper(k.CUSTOMER_NAME) like upper('%CAS Corporate Governance Services, Inc.%')
        OR upper(k.CUSTOMER_NAME) like upper('%Badger Daylighting Inc%')
        OR upper(k.CUSTOMER_NAME) like upper('%ENCORE ENERGY CORP.%'))
        AND k.CREATED_DATE >= TO_DATE ('2024/05/26', 'yyyy/mm/dd')
        AND k.CURRENT_STATUS_CD in (545 , 530)
        AND k.FF_TEAM_MEMBER_ID not in (11985419,11325333,12142542,11357163,12142481,12192056,12704959,11985467,10015945,12973313,12613663,13208749,12709339,12579023,13078339,13099631,13097480,13108517);
        COMMIT;

--71g_EFV_ORDER_UPD_Apeksha_Kambli


UPDATE EFARMS.EFV_ORDER k
  SET
    FF_TEAM_ID = 4799935,
    FF_TEAM_NAME = 'CT FMAR Rep',
    FF_TEAM_MEMBER_ID = 11325333,
    FF_TEAM_MEMBER_NAME = 'Apeksha Kambli',
    LAST_MODIFIED_BY = 'SYSTEM',
    LAST_MODIFIED_DATE = SYSDATE
  WHERE
(upper(k.CUSTOMER_NAME) like upper('%AT&'||'T Inc.%')
        OR upper(k.CUSTOMER_NAME) like upper('%Carollo Engineers%')
        OR upper(k.CUSTOMER_NAME) like upper('%Walmart Inc.%')
        OR upper(k.CUSTOMER_NAME) like upper('%DIRECTV%')
        OR upper(k.CUSTOMER_NAME) like upper('%Ally Financial-Tax%')
        OR upper(k.CUSTOMER_NAME) like upper('%Ally Financial Inc.%')
        OR upper(k.CUSTOMER_NAME) like upper('%CVS HEALTH COMPANIES%'))
   AND k.CREATED_DATE >= TO_DATE ('2024/05/26', 'yyyy/mm/dd')
   AND k.CURRENT_STATUS_CD in (545 , 530)
AND k.FF_TEAM_MEMBER_ID not in (11985419,11325333,12142542,11357163,12142481,12192056,12704959,11985467,10015945,12973313,12613663,13208749,12709339,12579023,13078339,13099631,13097480,13108517);


COMMIT;

--72g_EFV_ORDER_UPD_Surbhi_Joshi

UPDATE EFARMS.EFV_ORDER k
  SET
    FF_TEAM_ID = 4799935,
    FF_TEAM_NAME = 'CT FMAR Rep',
    FF_TEAM_MEMBER_ID = 12142542,
    FF_TEAM_MEMBER_NAME = 'Surbhi Joshi',
    LAST_MODIFIED_BY = 'SYSTEM',
    LAST_MODIFIED_DATE = SYSDATE
  WHERE
(upper(k.CUSTOMER_NAME) like upper('%JPMorgan Chase &'||'Co.%')
        OR upper(k.CUSTOMER_NAME) like upper('%J.P. Morgan Asset Management, Inc.%')
        OR upper(k.CUSTOMER_NAME) like upper('%Shell USA, Inc%')
        OR upper(k.CUSTOMER_NAME) like upper('%Premium Velocity Auto LLC%')
        OR upper(k.CUSTOMER_NAME) like upper('%SHELL MS FUEL CARD, LLC%')
        OR upper(k.CUSTOMER_NAME) like upper('%Presbyterian Church (U.S.A) Foundation%')
        OR upper(k.CUSTOMER_NAME) like upper('%Healthpeak, Inc%')
        OR upper(k.CUSTOMER_NAME) like upper('%Lyft, Inc%')
        OR upper(k.CUSTOMER_NAME) like upper('%MARRIOTT INTERNATIONAL, INC.%')
        OR upper(k.CUSTOMER_NAME) like upper('%MARRIOTT  INTERNATIONAL, INC.%')
        OR upper(k.CUSTOMER_NAME) like upper('%Silicon Valley Bank%')
        OR upper(k.CUSTOMER_NAME) like upper('%Preferred Credit, Inc.%')
        OR upper(k.CUSTOMER_NAME) like upper('%AECOM%')
        OR upper(k.CUSTOMER_NAME) like upper('%Morgan Stanley%')
        OR upper(k.CUSTOMER_NAME) like upper('%Morgan Stanley Real Estate Advisor, Inc.%')
        OR upper(k.CUSTOMER_NAME) like upper('%Morgan Stanley Smith Barney LLC%')
        OR upper(k.CUSTOMER_NAME) like upper('%Morgan Stanley Law Division%')
        OR upper(k.CUSTOMER_NAME) like upper('%Arthur J. Gallagher &'||'Co.%')
        OR upper(k.CUSTOMER_NAME) like upper('%SHELL ENERGY SOLUTIONS%')
        OR upper(k.CUSTOMER_NAME) like upper('%SAND CANYON CORPORATION%')
        OR upper(k.CUSTOMER_NAME) like upper('%The TJX Companies, Inc.%')
        OR upper(k.CUSTOMER_NAME) like upper('%Trusted Technologies, Inc.%')
        OR upper(k.CUSTOMER_NAME) like upper('%Babcock Power Inc.%')
        OR upper(k.CUSTOMER_NAME) like upper('%Rosen''s Diversified, Inc.%')
        OR upper(k.CUSTOMER_NAME) like upper('%NEXPOINT ADVISORS, LP%'))
   AND k.CREATED_DATE >= TO_DATE ('2024/05/26', 'yyyy/mm/dd')
   AND k.CURRENT_STATUS_CD in (545 , 530)
   AND k.FF_TEAM_MEMBER_ID not in (11985419,11325333,12142542,11357163,12142481,12192056,12704959,11985467,10015945,12973313,12613663,13208749,12709339,12579023,13078339,13099631,13097480,13108517);


COMMIT;


--73g_EFV_ORDER_UPD_Jyoti_Panelia

UPDATE EFARMS.EFV_ORDER k
  SET
    FF_TEAM_ID = 4799935,
    FF_TEAM_NAME = 'CT FMAR Rep',
    FF_TEAM_MEMBER_ID = 11357163,
    FF_TEAM_MEMBER_NAME = 'Jyoti Panelia',
    LAST_MODIFIED_BY = 'SYSTEM',
    LAST_MODIFIED_DATE = SYSDATE
  WHERE
(upper(k.CUSTOMER_NAME) like upper('%Resolve to Save Lives%')
        OR upper(k.CUSTOMER_NAME) like upper('%HIKMA PHARMACEUTICALS USA INC.%')
        OR upper(k.CUSTOMER_NAME) like upper('%SITA%')
        OR upper(k.CUSTOMER_NAME) like upper('%BP America Inc.%')
        OR upper(k.CUSTOMER_NAME) like upper('%PepsiCo, Inc.%')
        OR upper(k.CUSTOMER_NAME) like upper('%Matrix Service Company%')
        OR upper(k.CUSTOMER_NAME) like upper('%Platinum Equity Advisors, LLC%')
        OR upper(k.CUSTOMER_NAME) like upper('%Club Car, Inc.%')
        OR upper(k.CUSTOMER_NAME) like upper('%Cision US Inc.%')
        OR upper(k.CUSTOMER_NAME) like upper('%DELUXE MEDIA INC.%')
        OR upper(k.CUSTOMER_NAME) like upper('%Cabinetworks Group Michigan, LLC%')
        OR upper(k.CUSTOMER_NAME) like upper('%Club Car, LLC%')
        OR upper(k.CUSTOMER_NAME) like upper('%TAK COMMUNICATIONS, INC.%')
        OR upper(k.CUSTOMER_NAME) like upper('%Love''s Travel Stops and Country Stores, Inc.%')
        OR upper(k.CUSTOMER_NAME) like upper('%Tetra Tech, Inc.%'))
   AND k.CREATED_DATE >= TO_DATE ('2024/05/26', 'yyyy/mm/dd')
   AND k.CURRENT_STATUS_CD in (545 , 530)
   AND k.FF_TEAM_MEMBER_ID not in (11985419,11325333,12142542,11357163,12142481,12192056,12704959,11985467,10015945,12973313,12613663,13208749,12709339,12579023,13078339,13099631,13097480,13108517);


COMMIT;


--74g_EFV_ORDER_UPD_Ramiz_Maskewale

UPDATE EFARMS.EFV_ORDER k
  SET
    FF_TEAM_ID = 4799935,
    FF_TEAM_NAME = 'CT FMAR Rep',
    FF_TEAM_MEMBER_ID = 12142481,
    FF_TEAM_MEMBER_NAME = 'R Maskewale',
    LAST_MODIFIED_BY = 'SYSTEM',
    LAST_MODIFIED_DATE = SYSDATE
  WHERE
(upper(k.CUSTOMER_NAME) like upper('%NRG Energy Inc%')
        OR upper(k.CUSTOMER_NAME) like upper('%Hamilton Zanze &'||'Company%')
        OR upper(k.CUSTOMER_NAME) like upper('%Equity Residential%')
        OR upper(k.CUSTOMER_NAME) like upper('%Kimco Realty Corporation%')
        OR upper(k.CUSTOMER_NAME) like upper('%STRIPE, INC.%')
        OR upper(k.CUSTOMER_NAME) like upper('%BlackRock, Inc.%')
        OR upper(k.CUSTOMER_NAME) like upper('%Blackrock Inc, - GenPar%')
        OR upper(k.CUSTOMER_NAME) like upper('%Blackrock Investment Management, LLC%')
        OR upper(k.CUSTOMER_NAME) like upper('%Blackrock - Tcp Group%')
        OR upper(k.CUSTOMER_NAME) like upper('%Bio-Rad Laboratories, Inc.%')
        OR upper(k.CUSTOMER_NAME) like upper('%Danaher Corporation%'))
   AND k.CREATED_DATE >= TO_DATE ('2024/05/26', 'yyyy/mm/dd')
   AND k.CURRENT_STATUS_CD in (545 , 530)
   AND k.FF_TEAM_MEMBER_ID not in (11985419,11325333,12142542,11357163,12142481,12192056,12704959,11985467,10015945,12973313,12613663,13208749,12709339,12579023,13078339,13099631,13097480,13108517);

COMMIT;


--75g_EFV_ORDER_UPD_Amar_Sharma

UPDATE EFARMS.EFV_ORDER k
  SET
    FF_TEAM_ID = 4799935,
    FF_TEAM_NAME = 'CT FMAR Rep',
    FF_TEAM_MEMBER_ID = 12192056,
    FF_TEAM_MEMBER_NAME = 'Amar Sharma',
    LAST_MODIFIED_BY = 'SYSTEM',
    LAST_MODIFIED_DATE = SYSDATE
  WHERE
(upper(k.CUSTOMER_NAME) like upper('%Alliance HealthCare Services, Inc.%')
        OR upper(k.CUSTOMER_NAME) like upper('%Aetna Inc%')
        OR upper(k.CUSTOMER_NAME) like upper('%National Inventors Hall of Fame, Inc.%')
        OR upper(k.CUSTOMER_NAME) like upper('%Mill Creek Residential Trust LLC%')
        OR upper(k.CUSTOMER_NAME) like upper('%Best Buy Enterprise Services, Inc.%')
        OR upper(k.CUSTOMER_NAME) like upper('%HDR, Inc%')
        OR upper(k.CUSTOMER_NAME) like upper('%TRANSCONTINENTAL INC%')
        OR upper(k.CUSTOMER_NAME) like upper('%Upgrade, Inc.%')
        OR upper(k.CUSTOMER_NAME) like upper('%Tesla, Inc%')
        OR upper(k.CUSTOMER_NAME) like upper('%St. Joseph Health System%')
        OR upper(k.CUSTOMER_NAME) like upper('%GID Investment Advisers LLC%'))
   AND k.CREATED_DATE >= TO_DATE ('2024/05/26', 'yyyy/mm/dd')
   AND k.CURRENT_STATUS_CD in (545 , 530)
   AND k.FF_TEAM_MEMBER_ID not in (11985419,11325333,12142542,11357163,12142481,12192056,12704959,11985467,10015945,12973313,12613663,13208749,12709339,12579023,13078339,13099631,13097480,13108517);


COMMIT;

--76g_EFV_ORDER_UPD_Mohit_Jain

UPDATE EFARMS.EFV_ORDER k
  SET
    FF_TEAM_ID = 4799935,
    FF_TEAM_NAME = 'CT FMAR Rep',
    FF_TEAM_MEMBER_ID = 11985467,
    FF_TEAM_MEMBER_NAME = 'Mohit jain',
    LAST_MODIFIED_BY = 'SYSTEM',
    LAST_MODIFIED_DATE = SYSDATE
  WHERE
(upper(k.CUSTOMER_NAME) like upper('%Cigna Companies%')
        OR upper(k.CUSTOMER_NAME) like upper('%JACOBS ENGINEERING GROUP INC.%'))
   AND k.CREATED_DATE >= TO_DATE ('2024/05/26', 'yyyy/mm/dd')
   AND k.CURRENT_STATUS_CD in (545 , 530)
 AND k.FF_TEAM_MEMBER_ID not in (11985419,11325333,12142542,11357163,12142481,12192056,12704959,11985467,10015945,12973313,12613663,13208749,12709339,12579023,13078339,13099631,13097480,13108517);


COMMIT;

--77g_EFV_ORDER_UPD_Shivam_srivastava

UPDATE EFARMS.EFV_ORDER k
  SET
    FF_TEAM_ID = 4799935,
    FF_TEAM_NAME = 'CT FMAR Rep',
    FF_TEAM_MEMBER_ID = 12704959,
    FF_TEAM_MEMBER_NAME = 'Shivam srivastava',
    LAST_MODIFIED_BY = 'SYSTEM',
    LAST_MODIFIED_DATE = SYSDATE
  WHERE
(upper(k.CUSTOMER_NAME) like upper('%UnitedHealth Group Incorporated%'))
   AND k.CREATED_DATE >= TO_DATE ('2024/05/26', 'yyyy/mm/dd')
   AND k.CURRENT_STATUS_CD in (545 , 530)
  AND k.FF_TEAM_MEMBER_ID not in (11985419,11325333,12142542,11357163,12142481,12192056,12704959,11985467,10015945,12973313,12613663,13208749,12709339,12579023,13078339,13099631,13097480,13108517);


COMMIT;

--78g_EFV_ORDER_UPD_Kaushlendra_Singh

UPDATE EFARMS.EFV_ORDER k
  SET
    FF_TEAM_ID = 4799935,
    FF_TEAM_NAME = 'CT FMAR Rep',
    FF_TEAM_MEMBER_ID = 13335594,
    FF_TEAM_MEMBER_NAME = 'Kaushlendra Singh',
    LAST_MODIFIED_BY = 'SYSTEM',
    LAST_MODIFIED_DATE = SYSDATE
  WHERE
(upper(k.CUSTOMER_NAME) like upper('%Michels Corporation%'))
   AND k.CREATED_DATE >= TO_DATE ('2025/03/23', 'yyyy/mm/dd')
   AND k.CURRENT_STATUS_CD in (545 , 530)
   AND k.FF_TEAM_MEMBER_ID not in (13335594);

COMMIT;

--79g_EFV_ORDER_UPD_Shivam_srivastava

UPDATE EFARMS.EFV_ORDER k
  SET
    FF_TEAM_ID = 4799935,
    FF_TEAM_NAME = 'CT FMAR Rep',
    FF_TEAM_MEMBER_ID = 12704959,
    FF_TEAM_MEMBER_NAME = 'Shivam srivastava',
    LAST_MODIFIED_BY = 'SYSTEM',
    LAST_MODIFIED_DATE = SYSDATE
  WHERE
(upper(k.CUSTOMER_NAME) like upper('%Cerberus Capital Management L.P.%')
        OR upper(k.CUSTOMER_NAME) like upper('%Veolia North America%'))
   AND k.CREATED_DATE >= TO_DATE ('2025/06/15', 'yyyy/mm/dd')
   AND k.CURRENT_STATUS_CD in (545 , 530)
    AND k.FF_TEAM_MEMBER_ID not in (11985419,11325333,12142542,11357163,12142481,12192056,12704959,11985467,10015945,12973313,12613663,13208749,12709339,12579023,13078339,13099631,13097480,13108517);

COMMIT;

--80g_EFV_ORDER_UPD_Rahul_Gajjar

UPDATE EFARMS.EFV_ORDER k
  SET
    FF_TEAM_ID = 4799935,
    FF_TEAM_NAME = 'CT FMAR Rep',
    FF_TEAM_MEMBER_ID = 8765068,
    FF_TEAM_MEMBER_NAME = 'Rahul Gajjar',
    LAST_MODIFIED_BY = 'SYSTEM',
    LAST_MODIFIED_DATE = SYSDATE
  WHERE
(upper(k.CUSTOMER_NAME) like upper('%Citadel Enterprise Americas LLC%'))
   AND k.CREATED_DATE >= TO_DATE ('2025/05/04', 'yyyy/mm/dd')
   AND k.CURRENT_STATUS_CD in (545 , 530)
   AND k.FF_TEAM_MEMBER_ID not in (8765068);

COMMIT;

spool off;
exit;